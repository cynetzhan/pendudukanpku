
                    $('#tgl_terbit_artikel').datepicker({dateFormat: 'yy-mm-dd'});