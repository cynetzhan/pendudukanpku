_editor_url  = "/bonfire/themes/admin/js/editors/xinha/";
_editor_lang = "en";       // And the language we need to use in the editor.
_editor_skin = "silva";    // If you want use a skin, add the name (of the folder) here
_editor_icons = "classic"; // If you want to use a different iconset, add the name (of the folder, under the `iconsets` folder) here